# pacman
New Fb Cloning Commands PACMAN-Bolt
>>Features:
>>Friendlist cloning
>>Target bruteforce
>>Pakistan , india ,usa passlist included

>>>USE OLD VERISON OF TERMUX IF YOU FACE ANY LOGIN PROBLEM

apt update

apt upgrade

apt install python python2 git -y

pip2 install requests mechanize

git https://github.com/faizanwahla/pacman.git

cd pacman

python2 bolt
